package py.edu.uc.lp3_2025;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lp32025ApplicationTests {

	@Test
	void contextLoads() {
	}

}
