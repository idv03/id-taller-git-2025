package py.edu.uc.lp3_2025;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lp32025Application {

	public static void main(String[] args) {
		SpringApplication.run(Lp32025Application.class, args);
	}

}
